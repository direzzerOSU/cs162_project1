// include guard
#ifndef MENU_H
#define MENU_H

#include<iostream>
using std::cout;
using std::cin;
using std::endl;
#include<string>
using std::string;

// funtion protoype(s)
void menu(bool&);

#endif   // end of the include guard's scope
